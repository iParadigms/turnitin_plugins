$(document).ready(function(){
	window.location.href = $("#download_export_file").attr('href');
});